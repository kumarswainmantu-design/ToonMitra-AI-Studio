# ToonMitra AI Studio — Android starter project

Blue & White Android app starter built with Kotlin + Jetpack Compose.

## Included
- Home dashboard
- Create screen with story input, cartoon style, aspect ratio and language choices
- Projects placeholder
- Profile / Free plan placeholder
- Basic story-plan confirmation UI

## Important limitations
This is a **starter source project**, not a signed APK. It does not yet call an AI provider, generate images/audio/video, save projects to a server, or export MP4 files. Those features need a backend, provider credentials, secure server-side API calls, storage, and a video-rendering pipeline. Never put private API keys directly in the Android app.

## Build
1. Install Android Studio (current stable) and Android SDK 35.
2. Open this folder in Android Studio.
3. Let Gradle sync complete.
4. Run on an Android emulator or connected phone.
5. To create a test APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Package: `com.toonmitra.studio`
