package com.toonmitra.studio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Blue = Color(0xFF1769E0)
private val PaleBlue = Color(0xFFEAF2FF)
private val Ink = Color(0xFF14233B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ToonMitraApp() }
    }
}

@Composable
fun ToonMitraApp() {
    var page by remember { mutableStateOf("Home") }
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue, onPrimary = Color.White,
            background = Color(0xFFF7F9FD), surface = Color.White,
            onSurface = Ink
        )
    ) {
        Scaffold(
            containerColor = Color(0xFFF7F9FD),
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("Home", "Create", "Projects", "Profile").forEach { item ->
                        val icon = when(item) {
                            "Home" -> Icons.Default.Home
                            "Create" -> Icons.Default.AutoAwesome
                            "Projects" -> Icons.Default.VideoLibrary
                            else -> Icons.Default.Person
                        }
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = { Icon(icon, contentDescription = item) },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            when(page) {
                "Create" -> CreateScreen(Modifier.padding(padding))
                "Projects" -> ProjectsScreen(Modifier.padding(padding))
                "Profile" -> ProfileScreen(Modifier.padding(padding))
                else -> HomeScreen(
                    modifier = Modifier.padding(padding),
                    onCreate = { page = "Create" }
                )
            }
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier = Modifier, onCreate: () -> Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).background(Blue, RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
                Text("🎬", fontSize = 25.sp)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("ToonMitra", fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
                Text("AI STUDIO", fontSize = 11.sp, color = Blue, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            }
            Spacer(Modifier.weight(1f))
            Surface(color = PaleBlue, shape = RoundedCornerShape(20.dp)) {
                Text("FREE", color = Blue, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 13.dp, vertical = 7.dp))
            }
        }
        Spacer(Modifier.height(26.dp))
        Text("अपनी कहानी को कार्टून बनाओ!", fontSize = 27.sp, lineHeight = 34.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("Ideas से लेकर cartoon video plan तक — सब एक जगह।", color = Color(0xFF68758A), modifier = Modifier.padding(top = 7.dp))
        Spacer(Modifier.height(20.dp))
        Button(onClick = onCreate, modifier = Modifier.fillMaxWidth().height(55.dp), shape = RoundedCornerShape(16.dp)) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("नया Cartoon बनाएं", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(24.dp))
        Text("Create with AI", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(12.dp))
        FeatureCard("✍️", "Story Generator", "अपनी कहानी और डायलॉग तैयार करें", onCreate)
        FeatureCard("🖼️", "Image Prompts", "हर सीन के लिए cartoon image prompt", onCreate)
        FeatureCard("🎥", "Video Prompts", "सीन-बाय-सीन वीडियो निर्देश", onCreate)
        FeatureCard("🪄", "Thumbnail Maker", "YouTube के लिए thumbnail idea", onCreate)
        Spacer(Modifier.height(18.dp))
        Surface(color = PaleBlue, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("⭐ ToonMitra Pro", color = Blue, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("AI image, voice और video generation को जोड़ने के लिए Pro सेवाएँ उपलब्ध कराई जाएँगी।", color = Ink, modifier = Modifier.padding(top = 6.dp))
            }
        }
    }
}

@Composable
fun FeatureCard(emoji: String, title: String, subtitle: String, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { onClick() },
        color = Color.White, shape = RoundedCornerShape(16.dp), shadowElevation = 1.dp
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, fontSize = 27.sp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(subtitle, color = Color(0xFF738096), fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Blue)
        }
    }
}

@Composable
fun CreateScreen(modifier: Modifier = Modifier) {
    var idea by remember { mutableStateOf("") }
    var style by remember { mutableStateOf("3D Cartoon") }
    var ratio by remember { mutableStateOf("9:16 Shorts") }
    var language by remember { mutableStateOf("Hindi") }
    var result by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("Create Cartoon", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("अपना आइडिया लिखें और वीडियो प्लान बनाएं।", color = Color.Gray, modifier = Modifier.padding(top = 5.dp, bottom = 18.dp))
        Text("आपकी कहानी", fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = idea, onValueChange = { idea = it },
            placeholder = { Text("जैसे: दो दोस्तों की मजेदार कहानी...") },
            modifier = Modifier.fillMaxWidth().height(130.dp),
            shape = RoundedCornerShape(14.dp)
        )
        Spacer(Modifier.height(16.dp))
        Text("Cartoon Style", fontWeight = FontWeight.Bold)
        ChoiceRow(listOf("3D Cartoon", "Anime", "Cute 2D"), style) { style = it }
        Spacer(Modifier.height(14.dp))
        Text("Video Format", fontWeight = FontWeight.Bold)
        ChoiceRow(listOf("9:16 Shorts", "16:9 YouTube"), ratio) { ratio = it }
        Spacer(Modifier.height(14.dp))
        Text("Language", fontWeight = FontWeight.Bold)
        ChoiceRow(listOf("Hindi", "English", "Hinglish"), language) { language = it }
        Spacer(Modifier.height(20.dp))
        Button(onClick = { result = idea.isNotBlank() }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp)) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null)
            Spacer(Modifier.width(8.dp)); Text("Generate Story Plan")
        }
        if (result) {
            Spacer(Modifier.height(18.dp))
            Surface(color = PaleBlue, shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("आपका प्रोजेक्ट तैयार है", color = Blue, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Idea: $idea\nStyle: $style\nFormat: $ratio\nLanguage: $language", color = Ink, modifier = Modifier.padding(top = 8.dp))
                    Text("अगला चरण: AI backend जोड़कर scenes, images, voice और MP4 rendering चालू करना।", color = Color(0xFF52627A), modifier = Modifier.padding(top = 10.dp))
                }
            }
        }
        Spacer(Modifier.height(25.dp))
        Text("नोट: यह शुरुआती UI prototype है। अभी असली AI rendering चालू नहीं है।", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun ChoiceRow(options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
        options.forEach { option ->
            val active = option == selected
            Surface(
                color = if(active) PaleBlue else Color.White,
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, if(active) Blue else Color(0xFFDCE3EF)),
                modifier = Modifier.weight(1f).clickable { onSelect(option) }
            ) {
                Text(option, color = if(active) Blue else Ink, fontSize = 11.sp, fontWeight = if(active) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier.padding(vertical = 12.dp, horizontal = 4.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
        }
    }
}

@Composable
fun ProjectsScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("My Projects", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(14.dp))
        Surface(color = Color.White, shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = Blue, modifier = Modifier.size(34.dp))
                Text("अभी कोई project नहीं है", fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.padding(top = 10.dp))
                Text("आपके बनाए हुए story plans यहाँ दिखाई देंगे।", color = Color.Gray)
            }
        }
    }
}

@Composable
fun ProfileScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("Profile & Plan", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(16.dp))
        Surface(color = Color.White, shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("Current Plan: FREE", color = Blue, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Pro subscription और account sign-in को backend integration के अगले चरण में जोड़ा जाएगा।", color = Ink, modifier = Modifier.padding(top = 8.dp))
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("App Version 1.0 • ToonMitra AI Studio", color = Color.Gray, fontSize = 12.sp)
    }
}
